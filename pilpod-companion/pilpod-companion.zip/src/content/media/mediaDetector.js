/**
 * Page media detection — authoritative detector for content script snapshots.
 */

"use strict";

function allMediaElements() {
  return [
    ...document.querySelectorAll("video"),
    ...document.querySelectorAll("audio"),
  ];
}

function mediaElementsWithData() {
  return allMediaElements().filter((el) => el.readyState > 0);
}

export function activeMediaElement() {
  const all     = mediaElementsWithData();
  const playing = all.find((el) => !el.paused && !el.ended && el.readyState > 2);
  if (playing) return playing;
  return all.find((el) => el.paused && el.readyState > 0) ?? null;
}

function hasPlayingMediaElement() {
  return allMediaElements().some(
    (el) => !el.paused && !el.ended && el.readyState > 2,
  );
}

export function resolvePlaybackState() {
  const all = mediaElementsWithData();
  if (hasPlayingMediaElement()) return "playing";
  if (all.some((el) => el.paused && el.readyState > 0)) return "paused";

  // MediaSession alone is unreliable on background tabs (e.g. YouTube /watch opened in a new tab).
  const ms = navigator.mediaSession?.playbackState;
  if (ms === "playing" || ms === "paused") {
    if (document.visibilityState === "visible") return ms;
    return "none";
  }

  return "none";
}

function resolveHasSignal() {
  if (hasPlayingMediaElement()) return true;
  if (document.visibilityState !== "visible") return false;
  return navigator.mediaSession?.playbackState === "playing";
}

export function pickArtworkUrl() {
  const artwork = navigator.mediaSession?.metadata?.artwork ?? [];

  if (artwork.length > 0) {
    let bestSrc = "";
    let bestW   = 0;
    for (const a of artwork) {
      if (!a?.src) continue;
      const w = parseInt(String(a.sizes ?? "").split(/[x×]/)[0], 10) || 0;
      if (w > bestW || !bestSrc) { bestW = w; bestSrc = String(a.src); }
    }
    if (bestSrc) return bestSrc;
  }

  const poster = document.querySelector("video")?.poster;
  return poster ? String(poster) : "";
}


/** @param {{ idleMs: number }} activityTracker */
export function detectMedia(url, activityTracker) {
  const sessionMeta = navigator.mediaSession?.metadata;
  const title       = String(sessionMeta?.title ?? document.title ?? "");
  const artist      = String(sessionMeta?.artist ?? "");
  const album       = String(sessionMeta?.album ?? "");
  const active      = activeMediaElement();

  return {
    hasSignal: resolveHasSignal(),
    title,
    artist,
    album,
    playbackState: resolvePlaybackState(),
    artworkUrl: pickArtworkUrl(),
    url,
    duration: active?.duration ?? 0,
    currentTime: active?.currentTime ?? 0,
    pageVisible: document.visibilityState === "visible",
    userIdleMs: activityTracker.idleMs,
    documentState: document.readyState,
  };
}

export function hasActiveMedia() {
  const state = resolvePlaybackState();
  return state === "playing" || state === "paused";
}

/** @param {string} url */
export function needsMediaSessionFallback(_url) {
  if (allMediaElements().some((el) => el.readyState >= 1)) return false;
  if (document.hidden && !hasActiveMedia()) return false;

  const ms = navigator.mediaSession;
  if (!ms) return false;
  if (ms.playbackState === "playing" || ms.playbackState === "paused") return true;

  const metaTitle = ms.metadata?.title ?? "";
  return metaTitle.length > 0;
}

export { allMediaElements };
