use tauri::{AppHandle, State};

use crate::browser_bridge::WsConnectionMap;
use crate::browser_focus_win;
use crate::browser_tabs::{enqueue_browser_command, BrowserCommandsQueue};

#[tauri::command]
pub fn browser_media_control(
    app: AppHandle,
    queue: State<'_, BrowserCommandsQueue>,
    ws_connections: State<'_, WsConnectionMap>,
    browser_id: String,
    tab_id: i32,
    action: String,
    tab_title_for_focus: Option<String>,
    browser_window_hint: Option<String>,
    value: Option<f64>,
) -> Result<(), String> {
    if browser_id.is_empty() {
        return Err("browserId is required".into());
    }
    let a = action.trim().to_ascii_lowercase();
    let normalized = match a.as_str() {
        "playpause" | "play_pause" | "toggle" => "playPause",
        "next" | "skipnext" => "next",
        "previous" | "prev" | "skipprevious" => "previous",
        "focustab" | "focus_tab" | "focus" => "focusTab",
        "focuswindow" | "focus_window" => "focusWindow",
        "reactivatetab" | "reactivate_tab" => "reactivateTab",
        "reloadtab" | "reload_tab" => "reloadTab",
        "closetab" | "close_tab" => "closeTab",
        "seek" => "seek",
        "settabvolume" | "set_tab_volume" => "setTabVolume",
        "mutetab" | "mute_tab" => "muteTab",
        "pip" | "pictureinpicture" | "picture_in_picture" => "pip",
        _ => return Err(format!("unknown action: {action}")),
    };

    // The in-app player is a media source like any tab, but it lives in our own
    // webview — no extension, no socket. One branch keeps every control in the
    // dashboard working for it unchanged.
    if browser_id == crate::inapp_player::INAPP_BROWSER_ID {
        return if crate::inapp_player::send_command(&app, normalized, value) {
            Ok(())
        } else {
            Err("in-app player is not running".into())
        };
    }

    let outbound_value = if normalized == "setTabVolume" {
        value.map(super::volume_scale::app_to_ext_volume)
    } else {
        value
    };

    enqueue_browser_command(
        &queue,
        Some(&ws_connections),
        &browser_id,
        tab_id,
        normalized,
        outbound_value,
    );
    if normalized == "focusTab" {
        let title = tab_title_for_focus.unwrap_or_default();
        let hint = browser_window_hint.unwrap_or_default();
        browser_focus_win::spawn_raise_browser_window(title, hint);
    }
    Ok(())
}
